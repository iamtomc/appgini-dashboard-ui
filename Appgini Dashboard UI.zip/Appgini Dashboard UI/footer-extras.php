<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>Version</b> 1.1.0
	</div>
	<!--you can change the content below here according to your project-->
	<strong>Appgini Dashboard UI &nbsp;<a href="http://www.ronaldngoda.rf.gd">Pro Version</a>.</strong>
</footer>