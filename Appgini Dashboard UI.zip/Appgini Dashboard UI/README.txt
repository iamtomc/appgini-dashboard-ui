This is Appgini Dashboard UI kit
It will enable you transform your appgini application main interface to a professional looking
inteface using adminLTE
The documentation is provided in the documentation folder.Read all the instructions carefully on how to
change your application interface
You can use this kit in as many appgini projects that you have once you have already purchased it.
For any clarification feel free to contact me 
email:ronniengoda@gmail.com
website:ronaldngoda@gmail.com
phone:+254708344101